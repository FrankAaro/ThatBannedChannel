Readme.md

8-8-21

This is an addon for Kodi media player which allows users to watch banned content creators, documentaries, and viral videos.
It is the goal to allow freedom loving individuals who would otherwise be unable to watch their favorite content creators
like Alex Jones, David Knight, Mike Adams, and others on streaming platforms like YouTube or video streaming devices like Roku.
Kodi is a great way to get around the censorship created through Roku and YouTube. It is intended to be used with a Raspberry Pi 4 & 400
which support USB boot. 

Appreciate any suggestions on improving the project.

Thanks, Aaron.
