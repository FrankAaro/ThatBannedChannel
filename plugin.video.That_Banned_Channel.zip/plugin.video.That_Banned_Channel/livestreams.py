AlexJonesShow = {'A - The Alex Jones Show': [{'name': 'Alex Jones Livestream',
                                              'thumb': 'https://assets.infowarsmedia.com/images/bb7b6057-60cd-4d65-b226-38a93b17c42e-large.jpg',
                                              'video': 'https://freespeech.akamaized.net/hls/live/2024573/live2/playlist.m3u8',
                                              'genre': 'News'}]
                 }

WarRoom = { 'B - War Room With Owen Shroyer': [{'name': 'War Room Livestream',
                                                'thumb': 'https://assets.infowarsmedia.com/images/91a07c57-4dd3-4fc5-8022-cb866164b140-large.jpg',
                                                'video': 'https://freespeech.akamaized.net/hls/live/2024574/live4/playlist.m3u8',
                                                'genre': 'News'}]
                 }
                 
AmericanJournal = {'C - American Journal With Harrison Smith' : [{'name': 'American Journal Livestream',
                                                                  'thumb': 'https://assets.infowarsmedia.com/images/0ada7a98-85f2-433f-b654-7a87ec754784-large.jpg',
                                                                  'video': 'https://freespeech.akamaized.net/hls/live/2016873/live3/playlist.m3u8',
                                                                  'genre': 'News'}]
                 }

BannedVideoLive = {'D - 24/7 Livestream & Emergency Broadcasts' : [{'name': '24/7 Livestream',
                                                                    'thumb': 'https://assets.infowarsmedia.com/images/bb7b6057-60cd-4d65-b226-38a93b17c42e-large.jpg',
                                                                    'video': 'https://freespeech.akamaized.net/hls/live/2016712/live1/playlist.m3u8',
                                                                    'genre': 'News'}]
                 }
                 
BrighteonTv = {'E - Brighteon TV Livestream' : [{'name': 'Brighteon TV Livestream',
                                                 'thumb': 'icon.png',
				 							     'video': 'https://rtmp-edge.brighteon.com/hls/brighteon-live/index_720p/index.m3u8',
				 							     'genre': 'News'}]
		         }
